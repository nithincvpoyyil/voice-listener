import {Component} from '@angular/core';

@Component({
  selector: 'home',
  styleUrls: ['./home.css'],
  templateUrl: './home.html'
})
export class Home {

  public data:string[]=[];

  constructor(){}

  public getTheSearchString(text:string){
    if(text){
       this.data.push(text);
    }
   
  }
}
