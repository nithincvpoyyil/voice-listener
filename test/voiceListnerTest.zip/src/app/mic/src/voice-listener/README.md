# voice-listener
Component based reusable angularcomponent for voice based input using google APIs
