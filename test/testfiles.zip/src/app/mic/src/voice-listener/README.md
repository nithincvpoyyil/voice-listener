# voice-listener
A Angular2 reusable component for voice based input using google APIs
