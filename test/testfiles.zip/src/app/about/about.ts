import {Component} from '@angular/core';
import {VoiceListner} from'../mic/voicelistner'

@Component({
  selector: 'about',
  styleUrls: ['./about.css'],
  templateUrl: './about.html'
})
export class About {
}
